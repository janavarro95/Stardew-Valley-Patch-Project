﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace StardewValley.PatchedUtilities
{
  public class XNB_Utilities
    {
        /// <summary>
        /// Loads all blueprints from "Content\\Data\\Blueprints.xnb"
        /// </summary>
        /// <returns></returns>
        public static List<string> get_all_blueprint_keys_from_default_xnb()
        {
            List<string> my_string_list = new List<string>();
            Dictionary<string, string> dictionary = Game1.content.Load<Dictionary<string, string>>("Data\\Blueprints");

            foreach (var key in dictionary.Keys)
            {
                string text = null;
                dictionary.TryGetValue(key, out text);
                if (text != null)
                {
                    string[] array = text.Split(new char[]
                    {
                    '/'
                    });
                    if (array[0].Equals("animal"))
                    {
                        continue;
                    }
                    my_string_list.Add(key);
                    //default_stardew_buildings.Add(key);
                    //  Game1.showRedMessage(key);
                }
            }
            //Console.WriteLine("Dictionary keys count"+dictionary.Keys.Count);
            // Game1.showRedMessage(dictionary.Keys.Count.ToString());
            return my_string_list;
        }
        /// <summary>
        /// Loads all blueprints from a specific xnb at "Content\\Data\\Blueprints\\" + file_name"
        /// </summary>
        /// <param name="file_name"></param>
        /// <returns></returns>
        public static List<string> get_all_blueprint_keys_from_xnb(string file_name)
        {
            
            List<string> my_string_list = new List<string>();
            if (!Directory.Exists(Path.Combine(Game1.content.RootDirectory, "Data", "Blueprints"))) Directory.CreateDirectory(Path.Combine(Game1.content.RootDirectory, "Data", "Blueprints"));
            Dictionary<string, string> dictionary = Game1.content.Load<Dictionary<string, string>>("Data\\Blueprints\\" + file_name);

            foreach (var key in dictionary.Keys)
            {
                string text = null;
                dictionary.TryGetValue(key, out text);
                if (text != null)
                {
                    string[] array = text.Split(new char[]
                    {
                    '/'
                    });
                    if (array[0].Equals("animal"))
                    {
                        continue;
                    }
                    my_string_list.Add(key);
                    //default_stardew_buildings.Add(key);
                    //  Game1.showRedMessage(key);
                }
            }
            // Console.WriteLine("Dictionary keys count" + dictionary.Keys.Count);
            // Game1.showRedMessage(dictionary.Keys.Count.ToString());
            return my_string_list;
        }

        public static Dictionary<string,string> get_all_blueprint_keys_from_all_xnbs_in_extended_directory()
        {
            List<string> buildings_to_add = new List<string>(); //grabs all the keys from an xnb
            Dictionary<string,string> string_return_list = new Dictionary<string, string>();  //<xnb_file_name, building_name>
            string target_directory = Path.Combine(Game1.content.RootDirectory, "Data", "Blueprints");
            if (Directory.Exists(target_directory))
            {
                String[] fileEntries =
Directory.GetFiles(target_directory, "*.xnb")
.Select(fileName => Path.GetFileNameWithoutExtension(fileName))
.ToArray();
                foreach (string fileName in fileEntries)
                {
                    buildings_to_add = StardewValley.PatchedUtilities.XNB_Utilities.get_all_blueprint_keys_from_xnb(fileName);
                    foreach (string my_string in buildings_to_add)
                    {
                        string_return_list.Add(fileName,my_string);
                    }
                    buildings_to_add.Clear();
                }
            }
            else
            {
                Directory.CreateDirectory(target_directory);
                //Game1.showRedMessage(target_directory+" does not exist!");
            }
            return string_return_list;
        }
    }
}
